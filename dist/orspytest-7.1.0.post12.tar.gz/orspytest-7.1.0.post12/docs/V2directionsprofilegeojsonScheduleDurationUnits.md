# V2directionsprofilegeojsonScheduleDurationUnits

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**date_based** | **bool** |  | [optional] 
**duration** | [**V2directionsprofilegeojsonScheduleDurationDuration**](V2directionsprofilegeojsonScheduleDurationDuration.md) |  | [optional] 
**duration_estimated** | **bool** |  | [optional] 
**time_based** | **bool** |  | [optional] 

[[Back to Model list]](../README.md#documentation_for_models) [[Back to API list]](../README.md#documentation_for_api_endpoints) [[Back to README]](../README.md)

