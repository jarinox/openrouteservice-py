# GeoJSONIsochroneBase

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**geometry** | [**GeoJSONIsochroneBaseGeometry**](GeoJSONIsochroneBaseGeometry.md) |  | [optional] 
**type** | **str** |  | [optional] 

[[Back to Model list]](../README.md#documentation_for_models) [[Back to API list]](../README.md#documentation_for_api_endpoints) [[Back to README]](../README.md)

