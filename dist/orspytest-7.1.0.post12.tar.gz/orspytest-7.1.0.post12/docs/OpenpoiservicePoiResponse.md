# OpenpoiservicePoiResponse

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**features** | [**list[GeoJSONFeaturesObject]**](GeoJSONFeaturesObject.md) |  | [optional] 
**type** | **str** |  | [optional] [default to 'FeatureCollection']

[[Back to Model list]](../README.md#documentation_for_models) [[Back to API list]](../README.md#documentation_for_api_endpoints) [[Back to README]](../README.md)

