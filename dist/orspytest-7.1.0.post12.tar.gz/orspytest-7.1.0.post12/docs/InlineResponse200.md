# InlineResponse200

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**attribution** | **str** |  | [optional] 
**geometry** | [**InlineResponse200Geometry**](InlineResponse200Geometry.md) |  | [optional] 
**timestamp** | **int** |  | [optional] 
**version** | **str** |  | [optional] 

[[Back to Model list]](../README.md#documentation_for_models) [[Back to API list]](../README.md#documentation_for_api_endpoints) [[Back to README]](../README.md)

