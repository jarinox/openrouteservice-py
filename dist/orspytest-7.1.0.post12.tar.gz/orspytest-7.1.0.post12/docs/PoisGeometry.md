# PoisGeometry

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**bbox** | **list[float]** | The pattern for this bbox string is minlon,minlat,maxlon,maxlat | [optional] 
**buffer** | **int** |  | [optional] 
**geojson** | **object** | This is a GeoJSON object. Is either Point, Polygon or LineString. | [optional] 

[[Back to Model list]](../README.md#documentation_for_models) [[Back to API list]](../README.md#documentation_for_api_endpoints) [[Back to README]](../README.md)

