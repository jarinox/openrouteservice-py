# JsonEdgeExtra

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**edge_id** | **str** | Id of the corresponding edge in the graph | [optional] 
**extra** | **object** | Extra info stored on the edge | [optional] 

[[Back to Model list]](../README.md#documentation_for_models) [[Back to API list]](../README.md#documentation_for_api_endpoints) [[Back to README]](../README.md)

