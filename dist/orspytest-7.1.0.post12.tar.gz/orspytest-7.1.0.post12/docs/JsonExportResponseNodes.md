# JsonExportResponseNodes

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**location** | **list[float]** | {longitude},{latitude} coordinates of the closest accessible point on the routing graph | [optional] 
**node_id** | **int** | Id of the corresponding node in the graph | [optional] 

[[Back to Model list]](../README.md#documentation_for_models) [[Back to API list]](../README.md#documentation_for_api_endpoints) [[Back to README]](../README.md)

