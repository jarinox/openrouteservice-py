# PoisFilters

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**category_group_ids** | **list[int]** |  | [optional] 
**category_ids** | **list[int]** |  | [optional] 
**fee** | **list[str]** | Filter example. | [optional] 
**name** | **list[str]** | Filter by name of the poi object. | [optional] 
**smoking** | **list[str]** | Filter example. | [optional] 
**wheelchair** | **list[str]** | Filter example. | [optional] 

[[Back to Model list]](../README.md#documentation_for_models) [[Back to API list]](../README.md#documentation_for_api_endpoints) [[Back to README]](../README.md)

