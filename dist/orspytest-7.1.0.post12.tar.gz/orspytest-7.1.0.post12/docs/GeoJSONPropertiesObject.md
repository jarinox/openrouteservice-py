# GeoJSONPropertiesObject

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**category_ids** | [**GeoJSONPropertiesObjectCategoryIds**](GeoJSONPropertiesObjectCategoryIds.md) |  | [optional] 
**distance** | **float** |  | [optional] 
**osm_id** | **float** |  | [optional] 
**osm_tags** | [**GeoJSONPropertiesObjectOsmTags**](GeoJSONPropertiesObjectOsmTags.md) |  | [optional] 
**osm_type** | **float** |  | [optional] 

[[Back to Model list]](../README.md#documentation_for_models) [[Back to API list]](../README.md#documentation_for_api_endpoints) [[Back to README]](../README.md)

