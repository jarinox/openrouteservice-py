# Gpx

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**gpx_route_elements** | **list[object]** |  | [optional] 

[[Back to Model list]](../README.md#documentation_for_models) [[Back to API list]](../README.md#documentation_for_api_endpoints) [[Back to README]](../README.md)

