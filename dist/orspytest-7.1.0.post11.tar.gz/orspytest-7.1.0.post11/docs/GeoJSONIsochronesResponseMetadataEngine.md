# GeoJSONIsochronesResponseMetadataEngine

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**build_date** | **str** | The date that the service was last updated | [optional] 
**graph_date** | **str** | The date that the graph data was last updated | [optional] 
**version** | **str** | The backend version of the openrouteservice that was queried | [optional] 

[[Back to Model list]](../README.md#documentation_for_models) [[Back to API list]](../README.md#documentation_for_api_endpoints) [[Back to README]](../README.md)

