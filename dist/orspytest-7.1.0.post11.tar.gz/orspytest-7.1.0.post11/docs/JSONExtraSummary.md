# JSONExtraSummary

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**amount** | **float** | Category percentage of the entire route. | [optional] 
**distance** | **float** | Cumulative distance of this value. | [optional] 
**value** | **float** | [Value](https://GIScience.github.io/openrouteservice/documentation/extra-info/Extra-Info.html) of a info category. | [optional] 

[[Back to Model list]](../README.md#documentation_for_models) [[Back to API list]](../README.md#documentation_for_api_endpoints) [[Back to README]](../README.md)

