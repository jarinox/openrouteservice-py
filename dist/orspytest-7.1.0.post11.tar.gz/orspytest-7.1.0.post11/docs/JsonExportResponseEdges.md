# JsonExportResponseEdges

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**from_id** | **int** | Id of the start point of the edge | [optional] 
**to_id** | **int** | Id of the end point of the edge | [optional] 
**weight** | **float** | Weight of the corresponding edge in the given bounding box | [optional] 

[[Back to Model list]](../README.md#documentation_for_models) [[Back to API list]](../README.md#documentation_for_api_endpoints) [[Back to README]](../README.md)

