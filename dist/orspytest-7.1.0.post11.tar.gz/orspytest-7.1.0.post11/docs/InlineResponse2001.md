# InlineResponse2001

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**attribution** | **str** |  | [optional] 
**geometry** | [**InlineResponse2001Geometry**](InlineResponse2001Geometry.md) |  | [optional] 
**timestamp** | **int** |  | [optional] 
**version** | **str** |  | [optional] 

[[Back to Model list]](../README.md#documentation_for_models) [[Back to API list]](../README.md#documentation_for_api_endpoints) [[Back to README]](../README.md)

