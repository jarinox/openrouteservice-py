# V2directionsprofilegeojsonWalkingTime

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**nano** | **int** |  | [optional] 
**negative** | **bool** |  | [optional] 
**seconds** | **int** |  | [optional] 
**units** | [**list[V2directionsprofilegeojsonScheduleDurationUnits]**](V2directionsprofilegeojsonScheduleDurationUnits.md) |  | [optional] 
**zero** | **bool** |  | [optional] 

[[Back to Model list]](../README.md#documentation_for_models) [[Back to API list]](../README.md#documentation_for_api_endpoints) [[Back to README]](../README.md)

