# GeoJSONFeaturesObject

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**feature_properties** | [**GeoJSONPropertiesObject**](GeoJSONPropertiesObject.md) |  | [optional] 
**geometry** | [**GeoJSONGeometryObject**](GeoJSONGeometryObject.md) |  | [optional] 
**type** | **str** |  | [optional] [default to 'Feature']

[[Back to Model list]](../README.md#documentation_for_models) [[Back to API list]](../README.md#documentation_for_api_endpoints) [[Back to README]](../README.md)

